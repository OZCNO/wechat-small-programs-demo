var rank_list = [
  {
    "name": "回火",
    "grade": "100",
    "time": "3s",
    "money": "970.25"
  },
  {
    "name": "小红",
    "grade": "95",
    "time": "2s",
    "money": "800.00"
  }
]
var res={
  "code": 0,

  "beauty": 81,
  "beauty_rank": "三百六十度无死角的仰慕，简直帅绝人寰",
  "beauty_rank1": "三百六十度无死角的仰慕",
  "beauty_rank2": "简直帅绝人寰",


  "sex": "女",
  "age": 14,
  "sexAndAge_rank": "正处青春年华，如春花初放，似莲之清纯。",
  "sex_rank":"正处青春年华",
  "age_rank":"如春花初放，似莲之清纯",

  "happy": 11,
  "happy_rank": "害羞啥呢？",

  "wmoney": 200.00,
  "money":40
}

module.exports = {
  rankList: rank_list,
  res:res
}